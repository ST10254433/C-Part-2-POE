﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Moq;
using LecturerClaimSystem.Controllers;
using LecturerClaimSystem.Models; // Ensure this matches your Claim model namespace
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using WebApplication3.Data;

namespace LecturerClaimSystem.Tests
{
    public class ClaimsControllerTests
    {
        private readonly ClaimsController _controller;
        private readonly Mock<DbSet<Claim>> _mockSet;
        private readonly Mock<ApplicationDbContext> _mockContext;

        public ClaimsControllerTests()
        {
            // Mock the DbSet for Claims
            _mockSet = new Mock<DbSet<Claim>>();
            _mockContext = new Mock<ApplicationDbContext>();

            // Set up the mock context to return the mock set for Claims
            _mockContext.Setup(m => m.Claims).Returns(_mockSet.Object);

            // Initialize the controller with the mocked context and TempData
            var tempData = new TempDataDictionary(new DefaultHttpContext(), new SessionStateTempDataProvider(new SystemTextJsonSerializer()));
            _controller = new ClaimsController(_mockContext.Object)
            {
                TempData = tempData
            };
        }

        [Fact]
        public async Task Index_ReturnsViewResult_WithListOfClaims()
        {
            // Arrange
            var claims = new List<Claim>
            {
                new Claim { Id = 1, LecturerName = "John", Notes = "Test note" },
                new Claim { Id = 2, LecturerName = "Jane", Notes = "Another note" }
            }.AsQueryable();

            // Set up the mock set to return the claims
            _mockSet.As<IQueryable<Claim>>().Setup(m => m.Provider).Returns(claims.Provider);
            _mockSet.As<IQueryable<Claim>>().Setup(m => m.Expression).Returns(claims.Expression);
            _mockSet.As<IQueryable<Claim>>().Setup(m => m.ElementType).Returns(claims.ElementType);
            _mockSet.As<IQueryable<Claim>>().Setup(m => m.GetEnumerator()).Returns(claims.GetEnumerator());

            // Act
            var result = await _controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<List<Claim>>(viewResult.Model);
            Assert.Equal(2, model.Count);
        }

        [Fact]
        public async Task Create_AddsClaim_RedirectsToIndex()
        {
            // Arrange
            var newClaim = new Claim { LecturerName = "Alice", Notes = "New Claim" };
            var fileMock = new Mock<IFormFile>(); // Mock an IFormFile
            var mockEntry = new Mock<EntityEntry<Claim>>();
            _mockContext.Setup(m => m.AddAsync(newClaim, It.IsAny<CancellationToken>())).ReturnsAsync(mockEntry.Object);

            // Act
            var result = await _controller.Create(newClaim, fileMock.Object);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectResult.ActionName);
        }

        // Add more tests as needed...
    }
}
