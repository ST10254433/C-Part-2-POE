﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Data; // Update to your correct namespace for ApplicationDbContext
using LecturerClaimSystem.Models;
using System.IO;
using System.Threading.Tasks;
using System.Linq;

namespace LecturerClaimSystem.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClaimsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Claims/Create
        public IActionResult Create()
        {
            return View();
        }

        public async Task<IActionResult> Index()
        {
            var claims = await _context.Claims.ToListAsync();

            // Debugging output
            Console.WriteLine($"Number of claims retrieved: {claims.Count}");
            foreach (var claim in claims)
            {
                Console.WriteLine($"Claim ID: {claim.Id}, Lecturer Name: {claim.LecturerName}");
            }

            return View(claims); // Pass the list to the view
        }


        // POST: Claims/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Claim claim, IFormFile supportingDocument)
        {
            if (!ModelState.IsValid)
            {
                if (supportingDocument != null)
                {
                    // Handle file upload
                    var uploadsDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");

                    if (!Directory.Exists(uploadsDirectory))
                    {
                        Directory.CreateDirectory(uploadsDirectory);
                    }

                    var filePath = Path.Combine(uploadsDirectory, supportingDocument.FileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await supportingDocument.CopyToAsync(stream);
                    }

                    claim.SupportingDocument = "/uploads/" + supportingDocument.FileName;
                }

                _context.Add(claim);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(claim); // Return the claim view if the model is invalid
        }


        // GET: Claims/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                return NotFound();
            }
            return View(claim); // Pass the claim model to the view for editing
        }


        // POST: Claims/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ClaimId,Notes,HourlyRate,NumberOfHours,LecturerName,LecturerSurname,EmployeeNumber,ContactDetails,Module,Programme,Status,SubmittedAt")] Claim claim)
        {
            if (id != claim.Id)
            {
                return NotFound(); // Return 404 if the claim ID doesn't match
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(claim);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClaimExists(claim.Id))
                    {
                        return NotFound(); // Return 404 if the claim no longer exists
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index)); // Redirect to Index after saving the edit
            }
            return View(claim); // Return the view if the model state is invalid
        }

        // GET: Claims/Review

        // GET: Claims/Track
        public async Task<IActionResult> Track()
        {
            var claims = await _context.Claims.ToListAsync();
            return View(claims);
        }

        public IActionResult Details(int id)
        {
            var claim = _context.Claims.Find(id);
            if (claim == null)
            {
                return NotFound();
            }
            return View(claim); // Pass the claim to the Details view
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteClaim(int id)
        {
            var claim = _context.Claims.Find(id);
            if (claim == null)
            {
                return NotFound();
            }

            _context.Claims.Remove(claim);
            _context.SaveChanges();

            return RedirectToAction("Delete"); // Redirect to the Delete view
        }

        [HttpGet]
        public IActionResult DeleteConfirm(int id)
        {
            var claim = _context.Claims.Find(id);
            if (claim == null)
            {
                return NotFound();
            }

            return View(claim); // Return the claim to the confirmation view
        }

        // POST: Claims/Delete/5
        // This will handle GET requests to show the confirmation view

        // This handles the POST request to actually delete the record
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim != null)
            {
                _context.Claims.Remove(claim);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "The claim has been successfully deleted.";
            }
            else
            {
                TempData["ErrorMessage"] = "Claim not found.";
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Review()
        {
            var claims = await _context.Claims.ToListAsync();
            return View(claims); // Ensure you're returning the claims list
        }


        // Helper method to check if a claim exists
        private bool ClaimExists(int id)
        {
            return _context.Claims.Any(e => e.Id == id);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Approve(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                return NotFound();
            }
            claim.Status = "Approved";
            _context.Update(claim);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Review));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Reject(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                return NotFound();
            }
            claim.Status = "Rejected";
            _context.Update(claim);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Review));
        }
    }
}
