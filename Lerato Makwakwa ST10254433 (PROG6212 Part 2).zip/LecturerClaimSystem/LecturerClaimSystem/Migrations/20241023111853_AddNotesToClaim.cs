﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LecturerClaimSystem.Migrations
{
    /// <inheritdoc />
    public partial class AddNotesToClaim : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
