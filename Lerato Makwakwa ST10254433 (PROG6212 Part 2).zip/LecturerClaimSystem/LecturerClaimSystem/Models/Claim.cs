﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LecturerClaimSystem.Models
{
    public class Claim
    {
        public int Id { get; set; } // Primary key

        [MaxLength(500)] // for example, limit to 500 characters
        public string Notes { get; set; } // Notes property is present

        [Column(TypeName = "decimal(18,2)")]
        public decimal HourlyRate { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal NumberOfHours { get; set; }

        public string SupportingDocument { get; set; }

        [Required]
        public string LecturerName { get; set; }

        [Required]
        public string LecturerSurname { get; set; }

        [Required]
        public string EmployeeNumber { get; set; }

        [Required]
        public string ContactDetails { get; set; }

        public string? Module { get; set; } // Nullable string

        public string? Programme { get; set; } // Nullable string

        public string Status { get; set; }

        public DateTime SubmittedAt { get; set; } = DateTime.Now;
    }
}


